import "./App.css";
import ConversionForm from "./components/ConversionForm";

function App() {
  return (
    <div className='App'>
      <h1>Conversions</h1>
      <ConversionForm />
    </div>
  );
}

export default App;
